import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { ThemeProvider, CssBaseline } from '@mui/material';
import { lightTheme, darkTheme } from './theme/theme';
import Header from './components/Header';
import Footer from './components/Footer';
import LoginPage from './components/LoginPage';
import SignupPage from './components/SignupPage';
import HomePage from './components/HomePage';
import FeedbackPage from './components/FeedbackPage';
import UserProfile from './components/UserProfile';
import OtpVerification from './components/OtpVerification';
import './App.css';

function App() {
  const [userSignupPayload, setUserSignupPayload] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);
  const [darkMode, setDarkMode] = useState(false);
  const [registeredUsers, setRegisteredUsers] = useState([]);
  const [otp, setOtp] = useState('');

  // Load saved theme preference
  useEffect(() => {
    const savedDarkMode = localStorage.getItem('darkMode') === 'true';
    setDarkMode(savedDarkMode);
  }, []);

  useEffect(() => {
    console.log('Registered Users:', registeredUsers);
    // Save registered users to localStorage
    localStorage.setItem('registeredUsers', JSON.stringify(registeredUsers));
  },[registeredUsers]);

  // Toggle theme function
  const toggleDarkMode = () => {
    const newDarkMode = !darkMode;
    setDarkMode(newDarkMode);
    localStorage.setItem('darkMode', newDarkMode.toString());
  };

  // Check for logged in user on application load
  useEffect(() => {
    const storedUser = localStorage.getItem('currentUser');
    if (storedUser) {
      setCurrentUser(JSON.parse(storedUser));
    }
  }, []);

  // Private route component to protect routes that require authentication
  const PrivateRoute = ({ children }) => {
    return currentUser ? children : <Navigate to="/login" />;
  };

  const handleSignupComplete = (data, generatedOtp) => {
    setUserSignupPayload(data);
    setOtp(generatedOtp);
  };

  const handleOTPVerified = () => {
    setRegisteredUsers((prevUsers) => [...prevUsers, userSignupPayload]);
  }

  return (
    <ThemeProvider theme={darkMode ? darkTheme : lightTheme}>
      <CssBaseline /> {/* Applies base styles and resets according to theme */}
      <Router>
        <div className="app-container">
          <Header
            currentUser={currentUser}
            setCurrentUser={setCurrentUser}
            darkMode={darkMode}
            toggleDarkMode={toggleDarkMode}
          />

          <main className="content">
            <Routes>
              <Route path="/login" element={<LoginPage registeredUsers={registeredUsers} setCurrentUser={setCurrentUser} />} />
              <Route path="/signup" element={<SignupPage onComplete={handleSignupComplete}/>}/>
              <Route path="/otp" element={<OtpVerification userSignupPayload={userSignupPayload} otp={otp} onComplete={handleOTPVerified}/>}/>
              <Route path="/" element={
                currentUser ?
                  <HomePage currentUser={currentUser} /> :
                  <LoginPage registeredUsers={registeredUsers} setCurrentUser={setCurrentUser} />
                  // <Navigate to="/" />
              } />
              <Route path="/feedback" element={<FeedbackPage />} />
              <Route path="/profile" element={
                <PrivateRoute>
                  <UserProfile registeredUsers={registeredUsers} currentUser={currentUser} setCurrentUser={setCurrentUser} />
                </PrivateRoute>
              } />
            </Routes>
          </main>

          <Footer />
        </div>
      </Router>
    </ThemeProvider>
  );
}

export default App;