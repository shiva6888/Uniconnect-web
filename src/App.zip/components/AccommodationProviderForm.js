// src/components/AccommodationProviderForm.js
import React, { useState } from 'react';
import { Button, Grid, Typography, Checkbox, FormControlLabel } from '@mui/material';
import { Phone } from '@mui/icons-material';
import FormTextField from './FormTextField';
import { validatePhoneNumber, validateEmail, validateURL, validatePassword } from '../utils/validationUtils';

const AccommodationProviderForm = ({ onSubmit }) => {
  const [formData, setFormData] = useState({
    profileType: 'accommodationProvider',
    businessName: '',
    contactPerson: { firstName: '', lastName: '' },
    email: '',
    phoneNumber: '',
    whatsAppNumber: '',
    password: '',
    confirmPassword: '',
    website: '',
    termsAccepted: false,
  });

  const [errors, setErrors] = useState({});

  const validateForm = () => {
    let tempErrors = {};
    if (!formData.businessName) tempErrors.businessName = 'Business name is required';
    if (!formData.contactPerson.firstName) tempErrors.firstName = 'First name is required';
    if (!formData.contactPerson.lastName) tempErrors.lastName = 'Last name is required';
    if (!formData.email) tempErrors.email = 'Email is required';
    else if (!validateEmail(formData.email)) tempErrors.email = 'Invalid email format';
    if (!formData.phoneNumber) tempErrors.phoneNumber = 'Phone number is required';
    else if (!validatePhoneNumber(formData.phoneNumber)) tempErrors.phoneNumber = 'Invalid format (e.g., +1234567890)';
    if (formData.whatsAppNumber && !validatePhoneNumber(formData.whatsAppNumber)) {
      tempErrors.whatsAppNumber = 'Invalid format (e.g., +1234567890)';
    }
    if (!formData.password) tempErrors.password = 'Password is required';
    else if (!validatePassword(formData.password)) tempErrors.password = 'Password must be 8+ chars with letters and numbers';
    if (formData.password !== formData.confirmPassword) tempErrors.confirmPassword = 'Passwords must match';
    if (formData.website && !validateURL(formData.website)) tempErrors.website = 'Invalid URL (e.g., https://example.com)';
    if (!formData.termsAccepted) tempErrors.termsAccepted = 'You must accept the terms';

    setErrors(tempErrors);
    return Object.keys(tempErrors).length === 0;
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    if (name.includes('contactPerson')) {
      const field = name.split('.')[1];
      setFormData({
        ...formData,
        contactPerson: { ...formData.contactPerson, [field]: value },
      });
    } else {
      setFormData({ ...formData, [name]: type === 'checkbox' ? checked : value });
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validateForm()) onSubmit(formData);
  };

  return (
    <form onSubmit={handleSubmit}>
      <Grid container spacing={2}>
        <Grid item xs={12}>
          <FormTextField
            label="Business Name"
            name="businessName"
            value={formData.businessName}
            onChange={handleChange}
            required
            error={errors.businessName}
            helperText={errors.businessName}
          />
        </Grid>
        <Grid item xs={6}>
          <FormTextField
            label="First Name"
            name="contactPerson.firstName"
            value={formData.contactPerson.firstName}
            onChange={handleChange}
            required
            error={errors.firstName}
            helperText={errors.firstName}
          />
        </Grid>
        <Grid item xs={6}>
          <FormTextField
            label="Last Name"
            name="contactPerson.lastName"
            value={formData.contactPerson.lastName}
            onChange={handleChange}
            required
            error={errors.lastName}
            helperText={errors.lastName}
          />
        </Grid>
        <Grid item xs={12}>
          <FormTextField
            label="Email"
            name="email"
            type="email"
            value={formData.email}
            onChange={handleChange}
            required
            error={errors.email}
            helperText={errors.email}
          />
        </Grid>
        <Grid item xs={12}>
          <FormTextField
            label="Phone Number"
            name="phoneNumber"
            value={formData.phoneNumber}
            onChange={handleChange}
            required
            error={errors.phoneNumber}
            helperText={errors.phoneNumber || 'Format: +1234567890'}
            adornment={<Phone />}
          />
        </Grid>
        <Grid item xs={12}>
          <FormTextField
            label="WhatsApp Number (Optional)"
            name="whatsAppNumber"
            value={formData.whatsAppNumber}
            onChange={handleChange}
            error={errors.whatsAppNumber}
            helperText={errors.whatsAppNumber || 'Format: +1234567890'}
            adornment={<Phone />}
          />
        </Grid>
        <Grid item xs={12}>
          <FormTextField
            label="Password"
            name="password"
            type="password"
            value={formData.password}
            onChange={handleChange}
            required
            error={errors.password}
            helperText={errors.password}
          />
        </Grid>
        <Grid item xs={12}>
          <FormTextField
            label="Confirm Password"
            name="confirmPassword"
            type="password"
            value={formData.confirmPassword}
            onChange={handleChange}
            required
            error={errors.confirmPassword}
            helperText={errors.confirmPassword}
          />
        </Grid>
        <Grid item xs={12}>
          <FormTextField
            label="Website (Optional)"
            name="website"
            value={formData.website}
            onChange={handleChange}
            error={errors.website}
            helperText={errors.website || 'Example: https://www.example.com'}
          />
        </Grid>
        <Grid item xs={12}>
          <FormControlLabel
            control={<Checkbox name="termsAccepted" checked={formData.termsAccepted} onChange={handleChange} />}
            label="I accept the terms and conditions"
          />
          {errors.termsAccepted && <Typography color="error">{errors.termsAccepted}</Typography>}
        </Grid>
        <Grid item xs={12}>
          <Button type="submit" variant="contained" color="primary" fullWidth sx={{ mt: 2 }}>
            Sign Up
          </Button>
        </Grid>
      </Grid>
    </form>
  );
};

export default AccommodationProviderForm;