import React from 'react';
import {
  Drawer as MuiDrawer,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Divider,
  Box,
  Typography,
  Toolbar
} from '@mui/material';
import {
  Home,
  Dashboard,
  Feedback,
  Help
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';

const Drawer = ({ open, onClose, currentUser, darkMode }) => {
  const navigate = useNavigate();

  const mainListItems = [
    {
      text: 'Home',
      icon: <Home />,
      onClick: () => { navigate('/'); onClose(); }
    },
    {
      text: 'Dashboard',
      icon: <Dashboard />,
      onClick: () => { navigate('/dashboard'); onClose(); }
    }
  ];

  const secondaryListItems = [
    {
      text: 'Feedback',
      icon: <Feedback />,
      onClick: () => { navigate('/feedback'); onClose(); }
    },
    {
      text: 'Help',
      icon: <Help />,
      onClick: () => { navigate('/help'); onClose(); }
    }
  ];

  return (
    <MuiDrawer
      open={open}
      onClose={onClose}
      variant="temporary"
      sx={{
        '& .MuiDrawer-paper': { 
          width: 240,
          boxSizing: 'border-box',
        },
      }}
    >
      <Toolbar />
      <Box sx={{ overflow: 'auto' }}>
        <List>
          {mainListItems.map((item, index) => (
            // Only show auth-required items if user is logged in
            (!item.auth || currentUser) && (
              <ListItem button key={index} onClick={item.onClick}>
                <ListItemIcon>
                  {item.icon}
                </ListItemIcon>
                <ListItemText primary={item.text} />
              </ListItem>
            )
          ))}
        </List>
        <Divider />
        <List>
          {secondaryListItems.map((item, index) => (
            <ListItem button key={index} onClick={item.onClick}>
              <ListItemIcon>
                {item.icon}
              </ListItemIcon>
              <ListItemText primary={item.text} />
            </ListItem>
          ))}
        </List>
      </Box>
    </MuiDrawer>
  );
};

export default Drawer;