import React, { useState } from 'react';
import '../App.css';

function FeedbackPage() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [feedback, setFeedback] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    
    // In a real app, you would send this data to a server
    console.log("Feedback submitted:", { name, email, feedback });
    
    // Clear form and show success message
    setName('');
    setEmail('');
    setFeedback('');
    setSubmitted(true);
    
    // Hide success message after 5 seconds
    setTimeout(() => {
      setSubmitted(false);
    }, 5000);
  };

  return (
    <div className="feedback-container">
      <h2>We Value Your Feedback</h2>
      
      {submitted && (
        <div className="success-message">
          Thank you for your feedback! We appreciate your input.
        </div>
      )}
      
      <form onSubmit={handleSubmit} className="feedback-form">
        <div className="form-group">
          <label htmlFor="name">Name</label>
          <input
            type="text"
            id="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </div>
        
        <div className="form-group">
          <label htmlFor="email">Email</label>
          <input
            type="email"
            id="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        
        <div className="form-group">
          <label htmlFor="feedback">Your Feedback</label>
          <textarea
            id="feedback"
            value={feedback}
            onChange={(e) => setFeedback(e.target.value)}
            rows="5"
            required
          ></textarea>
        </div>
        
        <button type="submit" className="submit-button">Submit Feedback</button>
      </form>
    </div>
  );
}

export default FeedbackPage;