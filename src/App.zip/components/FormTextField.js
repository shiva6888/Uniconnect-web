// src/components/FormTextField.js
import React from 'react';
import { TextField, InputAdornment } from '@mui/material';

const FormTextField = ({
  label,
  name,
  value,
  onChange,
  error,
  helperText,
  required = false,
  type = 'text',
  adornment,
  multiline = false,
  rows,
  fullWidth = true,
}) => (
  <TextField
    fullWidth={fullWidth}
    label={label}
    name={name}
    value={value}
    onChange={onChange}
    required={required}
    type={type}
    error={!!error}
    helperText={helperText}
    multiline={multiline}
    rows={rows}
    InputProps={adornment ? { startAdornment: <InputAdornment position="start">{adornment}</InputAdornment> } : null}
  />
);

export default FormTextField;