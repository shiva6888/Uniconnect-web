import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  AppBar,
  Box,
  Toolbar,
  IconButton,
  Typography,
  Menu,
  MenuItem,
  Avatar,
  Tooltip,
  Divider,
  ListItemIcon,
  Button,
  Badge,
  useTheme
} from '@mui/material';
import {
  Menu as MenuIcon,
  Brightness4,
  Brightness7,
  Settings,
  Logout,
  Person,
  Notifications
} from '@mui/icons-material';
import Drawer from './Drawer';

const Header = ({ 
  currentUser, 
  setCurrentUser, 
  darkMode, 
  toggleDarkMode 
}) => {
  const navigate = useNavigate();
  const theme = useTheme();
  
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [anchorEl, setAnchorEl] = useState(null);
  const [notificationsAnchorEl, setNotificationsAnchorEl] = useState(null);

  const handleMenu = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleNotificationsMenu = (event) => {
    setNotificationsAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleNotificationsClose = () => {
    setNotificationsAnchorEl(null);
  };

  const handleLogout = () => {
    handleClose();
    setCurrentUser(null);
    localStorage.removeItem('currentUser');
    navigate('/login');
  };

  const handleProfile = () => {
    handleClose();
    navigate('/profile');
  };

  const toggleDrawer = () => {
    setDrawerOpen(!drawerOpen);
  };

  const menuItems = [
    { 
      text: 'Profile', 
      icon: <Person />, 
      onClick: handleProfile 
    },
    { 
      text: 'Settings', 
      icon: <Settings />, 
      onClick: () => { handleClose(); navigate('/settings'); } 
    },
  ];

  const notificationsItems = [
    { 
      text: 'New message from Jane',
      time: '5 mins ago'
    },
    { 
      text: 'New feedback submitted',
      time: '1 hour ago'
    },
    { 
      text: 'Password changed successfully',
      time: 'Yesterday'
    },
  ];

  // If the user isn't logged in, you can either hide the header or show a simplified version
  if (!currentUser) {
    return null;
  }

  return (
    <>
      <AppBar position="fixed" sx={{ zIndex: (theme) => theme.zIndex.drawer + 1 }}>
        <Toolbar>
          <IconButton
            edge="start"
            color="inherit"
            aria-label="menu"
            sx={{ mr: 2 }}
            onClick={toggleDrawer}
          >
            <MenuIcon />
          </IconButton>
          
          <Typography 
            variant="h6" 
            component="div" 
            sx={{ flexGrow: 1, fontWeight: 'bold', cursor: 'pointer' }}
            onClick={() => navigate('/')}
          >
            Material App
          </Typography>

          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <IconButton 
              color="inherit" 
              onClick={toggleDarkMode}
              sx={{ mr: 1 }}
              aria-label="toggle dark mode"
            >
              {darkMode ? <Brightness7 /> : <Brightness4 />}
            </IconButton>
            
            <IconButton 
              color="inherit" 
              onClick={handleNotificationsMenu}
              sx={{ mr: 1 }}
            >
              <Badge badgeContent={3} color="error">
                <Notifications />
              </Badge>
            </IconButton>
            
            <Tooltip title="Account settings">
              <IconButton
                onClick={handleMenu}
                size="small"
                sx={{ ml: 1 }}
                aria-controls="menu-appbar"
                aria-haspopup="true"
              >
                <Avatar 
                  alt={currentUser?.firstName} 
                  src={currentUser?.profileImage}
                  sx={{ width: 32, height: 32 }}
                />
              </IconButton>
            </Tooltip>
          </Box>
        </Toolbar>
      </AppBar>
      
      <Menu
        id="menu-appbar"
        anchorEl={anchorEl}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'right',
        }}
        keepMounted
        transformOrigin={{
          vertical: 'top',
          horizontal: 'right',
        }}
        open={Boolean(anchorEl)}
        onClose={handleClose}
        sx={{ mt: 1 }}
      >
        <Box sx={{ py: 1, px: 2, display: 'flex', alignItems: 'center', gap: 1 }}>
          <Avatar 
            alt={currentUser?.firstName} 
            src={currentUser?.profileImage}
            sx={{ width: 32, height: 32 }}
          />
          <Box>
            <Typography variant="subtitle1">{`${currentUser?.firstName || ''} ${currentUser?.lastName || ''}`}</Typography>
            <Typography variant="body2" color="text.secondary">{currentUser?.role || ''}</Typography>
          </Box>
        </Box>
        
        <Divider />
        
        {menuItems.map((item, index) => (
          <MenuItem key={index} onClick={item.onClick}>
            <ListItemIcon>
              {item.icon}
            </ListItemIcon>
            {item.text}
          </MenuItem>
        ))}
        
        <Divider />
        
        <MenuItem onClick={handleLogout}>
          <ListItemIcon>
            <Logout fontSize="small" />
          </ListItemIcon>
          Logout
        </MenuItem>
      </Menu>
      
      <Menu
        id="notifications-menu"
        anchorEl={notificationsAnchorEl}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'right',
        }}
        keepMounted
        transformOrigin={{
          vertical: 'top',
          horizontal: 'right',
        }}
        open={Boolean(notificationsAnchorEl)}
        onClose={handleNotificationsClose}
        sx={{ mt: 1 }}
      >
        <Typography variant="subtitle1" sx={{ px: 2, py: 1, fontWeight: 'bold' }}>
          Notifications
        </Typography>
        <Divider />
        
        {notificationsItems.map((item, index) => (
          <MenuItem key={index} onClick={handleNotificationsClose}>
            <Box sx={{ display: 'flex', flexDirection: 'column' }}>
              <Typography variant="body2">{item.text}</Typography>
              <Typography variant="caption" color="text.secondary">{item.time}</Typography>
            </Box>
          </MenuItem>
        ))}
        
        <Divider />
        
        <Box sx={{ p: 1, display: 'flex', justifyContent: 'center' }}>
          <Button size="small" onClick={handleNotificationsClose}>
            View All
          </Button>
        </Box>
      </Menu>
      
      <Drawer 
        open={drawerOpen} 
        onClose={() => setDrawerOpen(false)} 
        currentUser={currentUser}
        darkMode={darkMode} 
      />
    </>
  );
};

export default Header;