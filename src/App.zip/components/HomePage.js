import React from 'react';
import '../App.css';

function HomePage({ currentUser }) {
  return (
    <div className="home-container">
      <h1>Welcome to MyApp</h1>
      
      {currentUser ? (
        <div className="welcome-message">
          <p>Hello, {currentUser.firstName}! We're glad you're here.</p>
          <p>This is your personalized dashboard.</p>
        </div>
      ) : (
        <div className="welcome-message">
          <p>Please log in to access your personalized dashboard.</p>
        </div>
      )}
      
      <div className="feature-section">
        <h2>Features</h2>
        <ul>
          <li>Secure login system</li>
          <li>User profile management</li>
          <li>Responsive design</li>
          <li>And much more!</li>
        </ul>
      </div>
    </div>
  );
}

export default HomePage;