// src/components/OtpVerification.js
import React, { useState } from 'react';
import { TextField, Button, Typography, Box } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { mockService } from './../mockService';

function OtpVerification({ userSignupPayload, otp, onComplete }) {
    const [userOtp, setUserOtp] = useState('');
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);
    const navigate = useNavigate();
    
    const handleChange = (e) => {
        const value = e.target.value;
        // Allow only numbers and limit to 4 characters
        if (value === '' || (/^\d+$/.test(value) && value.length <= 4)) {
            setUserOtp(value);
            setError('');
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        if (userOtp.length !== 4) {
            setError('Please enter a valid 4-digit OTP');
            return;
        }

        setLoading(true);

        try {
            const response = await mockService.verifyOtp(userSignupPayload, otp, userOtp);
            if (response.success) {
                // TODO
                // A beautiful information popup
                alert("User registered, please login to proceed.");
                onComplete();
                navigate('/login');
            } else {
                setError(response.message || 'Invalid OTP');
            }
        } catch (error) {
            console.error('OTP verification error:', error);
            setError('An error occurred during verification');
        } finally {
            setLoading(false);
        }
    };

    return (
        <form onSubmit={handleSubmit}>
            <Typography variant="body1" gutterBottom>
                We've sent a verification code to {userSignupPayload.email}. Please enter the 4-digit code below.
            </Typography>

            <Box mt={2} mb={2}>
                <TextField
                    label="Enter OTP"
                    fullWidth
                    value={userOtp}
                    onChange={handleChange}
                    error={!!error}
                    helperText={error}
                    inputProps={{ maxLength: 4 }}
                />
            </Box>

            <Button
                type="submit"
                fullWidth
                variant="contained"
                color="primary"
                disabled={loading}
            >
                {loading ? 'Verifying...' : 'Verify OTP'}
            </Button>

            <Typography variant="body2" sx={{ mt: 2, textAlign: 'center' }}>
                Didn't receive the code? Check your spam folder or contact support.
            </Typography>
        </form>
    );
}

export default OtpVerification;