// src/components/SignupPage.js
import React, { useState } from 'react';
import { Container, Paper, Typography, RadioGroup, FormControlLabel, Radio, Link } from '@mui/material';
import AccommodationProviderForm from './AccommodationProviderForm';
import EventOrganiserForm from './EventOrganiserForm';
import StudentForm from './StudentForm';
import { useNavigate } from 'react-router-dom'; // Added for navigation

const SignupPage = () => {
  const [profileType, setProfileType] = useState('accommodationProvider');
  const navigate = useNavigate(); // Added for navigation

  const handleProfileTypeChange = (event) => {
    setProfileType(event.target.value);
  };

  const handleFormSubmit = (formData) => {
    console.log('Submitted data:', formData);
    // Add API call here, e.g., fetch('/signup', { method: 'POST', body: JSON.stringify(formData) })
  };

  return (
    <Container maxWidth="sm">
      <Paper elevation={3} sx={{ p: 4, mt: 4 }}>
        <Typography variant="h5" gutterBottom>
          Sign Up
        </Typography>
        <RadioGroup row value={profileType} onChange={handleProfileTypeChange} sx={{ mb: 3 }}>
          <FormControlLabel value="accommodationProvider" control={<Radio />} label="Accommodation Provider" />
          <FormControlLabel value="eventOrganiser" control={<Radio />} label="Event Organiser" />
          <FormControlLabel value="student" control={<Radio />} label="Student" />
        </RadioGroup>

        {profileType === 'accommodationProvider' && <AccommodationProviderForm onSubmit={handleFormSubmit} />}
        {profileType === 'eventOrganiser' && <EventOrganiserForm onSubmit={handleFormSubmit} />}
        {profileType === 'student' && <StudentForm onSubmit={handleFormSubmit} />}

        {/* Added "Already have an account? Login" option */}
        <Typography variant="body2" align="center" sx={{ mt: 2 }}>
          Already have an account?{' '}
          <Link
            component="button"
            variant="body2"
            onClick={() => navigate('/login')} // Navigate to login page
          >
            Login
          </Link>
        </Typography>
      </Paper>
    </Container>
  );
};

export default SignupPage;