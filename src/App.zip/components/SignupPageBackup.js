// src/components/Signup.js
import React, { useState } from 'react';
import {
    TextField,
    Button,
    Grid,
    FormControl,
    InputLabel,
    Select,
    MenuItem,
    Typography,
    Link
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { mockService } from '../mockService';

function Signup({ onComplete }) {
    const [formData, setFormData] = useState({
        firstName: '',
        lastName: '',
        email: '',
        password: '',
        confirmPassword: '',
        profile: ''
    });

    const [errors, setErrors] = useState({});
    const [loading, setLoading] = useState(false);
    const navigate = useNavigate();

    const handleChange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value
        });

        // Clear error when field is modified
        if (errors[e.target.name]) {
            setErrors({
                ...errors,
                [e.target.name]: ''
            });
        }
    };

    const validateForm = () => {
        const newErrors = {};

        if (!formData.firstName.trim()) {
            newErrors.firstName = 'First name is required';
        }

        if (!formData.lastName.trim()) {
            newErrors.lastName = 'Last name is required';
        }

        if (!formData.email.trim()) {
            newErrors.email = 'Email is required';
        } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
            newErrors.email = 'Invalid email format';
        }

        if (!formData.password) {
            newErrors.password = 'Password is required';
        } else if (formData.password.length < 6) {
            newErrors.password = 'Password must be at least 6 characters';
        }

        if (formData.password !== formData.confirmPassword) {
            newErrors.confirmPassword = 'Passwords do not match';
        }

        if (!formData.profile) {
            newErrors.profile = 'Please select a profile';
        }

        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        if (!validateForm()) {
            return;
        }

        setLoading(true);

        try {
            const response = await mockService.registerUser(formData);
            if (response.success) {
                onComplete(formData, response.otp);
                navigate('/otp')
            }
        } catch (error) {
            console.error('Registration error:', error);
        } finally {
            setLoading(false);
        }
    };
    const handleSwitch = () => {
        navigate('/login');
      };
    return (
        <form onSubmit={handleSubmit}>
            <Grid container spacing={2}>
                <Grid item xs={12} sm={6}>
                    <TextField
                        name="firstName"
                        label="First Name"
                        fullWidth
                        value={formData.firstName}
                        onChange={handleChange}
                        error={!!errors.firstName}
                        helperText={errors.firstName}
                        required
                    />
                </Grid>

                <Grid item xs={12} sm={6}>
                    <TextField
                        name="lastName"
                        label="Last Name"
                        fullWidth
                        value={formData.lastName}
                        onChange={handleChange}
                        error={!!errors.lastName}
                        helperText={errors.lastName}
                        required
                    />
                </Grid>

                <Grid item xs={12}>
                    <TextField
                        name="email"
                        label="Email Address"
                        fullWidth
                        value={formData.email}
                        onChange={handleChange}
                        error={!!errors.email}
                        helperText={errors.email}
                        required
                    />
                </Grid>

                <Grid item xs={12}>
                    <TextField
                        name="password"
                        label="Password"
                        type="password"
                        fullWidth
                        value={formData.password}
                        onChange={handleChange}
                        error={!!errors.password}
                        helperText={errors.password}
                        required
                    />
                </Grid>

                <Grid item xs={12}>
                    <TextField
                        name="confirmPassword"
                        label="Confirm Password"
                        type="password"
                        fullWidth
                        value={formData.confirmPassword}
                        onChange={handleChange}
                        error={!!errors.confirmPassword}
                        helperText={errors.confirmPassword}
                        required
                    />
                </Grid>

                <Grid item xs={12}>
                    <FormControl fullWidth required error={!!errors.profile}>
                        <InputLabel id="profile-label">Profile</InputLabel>
                        <Select
                            labelId="profile-label"
                            name="profile"
                            value={formData.profile}
                            onChange={handleChange}
                            label="Profile"
                        >
                            <MenuItem value="student">Student</MenuItem>
                            <MenuItem value="eventOrganiser">Event Organiser</MenuItem>
                            <MenuItem value="accommodationProvider">Accommodation Provider</MenuItem>
                        </Select>
                        {errors.profile && <Typography color="error" variant="caption">{errors.profile}</Typography>}
                    </FormControl>
                </Grid>

                <Grid item xs={12}>
                    <Button
                        type="submit"
                        fullWidth
                        variant="contained"
                        color="primary"
                        disabled={loading}
                    >
                        {loading ? 'Submitting...' : 'Sign Up'}
                    </Button>
                </Grid>

                <Grid item xs={12} textAlign="center">
                    <Typography variant="body2">
                        Already have an account?{' '}
                        <Link
                            component="button"
                            variant="body2"
                            onClick={handleSwitch}
                        >
                            Log in
                        </Link>
                    </Typography>
                </Grid>
            </Grid>
        </form>
    );
}

export default Signup;