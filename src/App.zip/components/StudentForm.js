// src/components/StudentForm.js
import React, { useState, useEffect } from 'react';
import {
  Button,
  Grid,
  Typography,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Checkbox,
  FormControlLabel,
  Autocomplete,
  TextField,
} from '@mui/material';
import { Phone } from '@mui/icons-material';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import FormTextField from './FormTextField';
import { validatePhoneNumber, validateEmail, validateURL, validatePassword } from '../utils/validationUtils';
import { getNames } from 'country-list';

const countries = getNames();
// Mock data (replace with API calls in production)
const universities = ['Harvard', 'MIT', 'Stanford', 'Oxford', 'Cambridge'];
const coursesByUniversity = {
  Harvard: ['Computer Science', 'Physics', 'Biology'],
  MIT: ['Engineering', 'Mathematics', 'Robotics'],
  Stanford: ['Business', 'Psychology', 'Computer Science'],
  Oxford: ['History', 'Literature', 'Philosophy'],
  Cambridge: ['Economics', 'Chemistry', 'Medicine'],
};
const interestOptions = ['AI', 'Machine Learning', 'Data Science', 'Web Development', 'Photography'];
const accommodationOptions = ['1BHK', '2BHK', '3BHK', 'Studio', 'Shared Room'];

const StudentForm = ({ onSubmit }) => {
  const [formData, setFormData] = useState({
    profileType: 'student',
    firstName: '',
    lastName: '',
    dob: null, // Store as Date object
    countryOfOrigin: '',
    phoneNumber: '',
    email: '',
    password: '',
    confirmPassword: '',
    universityName: '',
    universityId: '',
    courseName: '',
    graduationYear: '',
    bio: '',
    interests: [],
    accommodationPreferences: [],
    profilePictureURL: '',
    socialMediaLinks: { linkedin: '', twitter: '' },
    termsAccepted: false,
  });

  const [errors, setErrors] = useState({});
  const [availableCourses, setAvailableCourses] = useState([]);
  const [graduationYears, setGraduationYears] = useState([]);

  useEffect(() => {
    const currentYear = new Date().getFullYear();
    const maxYear = currentYear + 10;
    const years = Array.from({ length: maxYear - currentYear + 1 }, (_, i) => currentYear + i);
    setGraduationYears(years);
  }, []);

  useEffect(() => {
    if (formData.universityName) {
      setAvailableCourses(coursesByUniversity[formData.universityName] || []);
      setFormData((prev) => ({ ...prev, courseName: '' }));
    }
  }, [formData.universityName]);

  const validateForm = () => {
    let tempErrors = {};
    if (!formData.firstName) tempErrors.firstName = 'First name is required';
    if (!formData.lastName) tempErrors.lastName = 'Last name is required';
    if (!formData.dob) tempErrors.dob = 'Date of birth is required';
    if (!formData.countryOfOrigin) tempErrors.countryOfOrigin = 'Country of origin is required';
    if (formData.phoneNumber && !validatePhoneNumber(formData.phoneNumber)) {
      tempErrors.phoneNumber = 'Invalid format (e.g., +1234567890)';
    }
    if (!formData.email) tempErrors.email = 'Email is required';
    else if (!validateEmail(formData.email)) tempErrors.email = 'Invalid email format';
    if (!formData.password) tempErrors.password = 'Password is required';
    else if (!validatePassword(formData.password))
      tempErrors.password = 'Password must be 8+ chars with letters and numbers';
    if (formData.password !== formData.confirmPassword)
      tempErrors.confirmPassword = 'Passwords must match';
    if (!formData.universityName) tempErrors.universityName = 'University is required';
    if (!formData.universityId) tempErrors.universityId = 'University ID is required';
    if (!formData.courseName) tempErrors.courseName = 'Course is required';
    if (!formData.graduationYear) tempErrors.graduationYear = 'Graduation year is required';
    if (formData.profilePictureURL && !validateURL(formData.profilePictureURL)) {
      tempErrors.profilePictureURL = 'Invalid URL format';
    }
    if (formData.socialMediaLinks.linkedin && !validateURL(formData.socialMediaLinks.linkedin)) {
      tempErrors.linkedin = 'Invalid LinkedIn URL';
    }
    if (formData.socialMediaLinks.twitter && !validateURL(formData.socialMediaLinks.twitter)) {
      tempErrors.twitter = 'Invalid Twitter URL';
    }
    if (!formData.termsAccepted) tempErrors.termsAccepted = 'You must accept the terms';

    setErrors(tempErrors);
    return Object.keys(tempErrors).length === 0;
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    if (name.includes('socialMediaLinks')) {
      const field = name.split('.')[1];
      setFormData({
        ...formData,
        socialMediaLinks: { ...formData.socialMediaLinks, [field]: value },
      });
    } else {
      setFormData({ ...formData, [name]: type === 'checkbox' ? checked : value });
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validateForm()) onSubmit(formData);
  };

  return (
    <LocalizationProvider dateAdapter={AdapterDateFns}>
      <form onSubmit={handleSubmit}>
        <Grid container spacing={2}>
          <Grid item xs={6}>
            <FormTextField
              label="First Name"
              name="firstName"
              value={formData.firstName}
              onChange={handleChange}
              required
              error={errors.firstName}
              helperText={errors.firstName}
            />
          </Grid>
          <Grid item xs={6}>
            <FormTextField
              label="Last Name"
              name="lastName"
              value={formData.lastName}
              onChange={handleChange}
              required
              error={errors.lastName}
              helperText={errors.lastName}
            />
          </Grid>
          <Grid item xs={12}>
            <DatePicker
              label="Date of Birth"
              value={formData.dob}
              onChange={(newValue) => setFormData({ ...formData, dob: newValue })}
              slotProps={{
                textField: {
                  required: true,
                  error: !!errors.dob,
                  helperText: errors.dob || 'Select your date of birth',
                },
              }}
            />
          </Grid>
          <Grid item xs={12}>
            <FormControl fullWidth error={!!errors.countryOfOrigin}>
              <InputLabel id="country-of-origin-label">Country of Origin</InputLabel>
              <Select
                labelId="country-of-origin-label"
                name="countryOfOrigin"
                value={formData.countryOfOrigin}
                onChange={handleChange}
                required
                variant="outlined"
                label="Country of Origin"
              >
                <MenuItem value="">
                  <em>None</em>
                </MenuItem>
                {countries.map((country) => (
                  <MenuItem key={country} value={country}>
                    {country}
                  </MenuItem>
                ))}
              </Select>
              {errors.countryOfOrigin && (
                <Typography color="error">{errors.countryOfOrigin}</Typography>
              )}
            </FormControl>
          </Grid>
          <Grid item xs={12}>
            <FormTextField
              label="Phone Number (Optional)"
              name="phoneNumber"
              value={formData.phoneNumber}
              onChange={handleChange}
              error={errors.phoneNumber}
              helperText={errors.phoneNumber || 'Format: +1234567890'}
              adornment={<Phone />}
            />
          </Grid>
          <Grid item xs={12}>
            <FormTextField
              label="Email"
              name="email"
              type="email"
              value={formData.email}
              onChange={handleChange}
              required
              error={errors.email}
              helperText={errors.email}
            />
          </Grid>
          <Grid item xs={12}>
            <FormTextField
              label="Password"
              name="password"
              type="password"
              value={formData.password}
              onChange={handleChange}
              required
              error={errors.password}
              helperText={errors.password}
            />
          </Grid>
          <Grid item xs={12}>
            <FormTextField
              label="Confirm Password" // Fixed label
              name="confirmPassword"
              type="password"
              value={formData.confirmPassword}
              onChange={handleChange}
              required
              error={errors.confirmPassword}
              helperText={errors.confirmPassword}
            />
          </Grid>
          <Grid item xs={12}>
            <Autocomplete
              options={universities}
              value={formData.universityName || null}
              onChange={(e, value) => setFormData({ ...formData, universityName: value || '' })}
              renderInput={(params) => (
                <TextField
                  {...params}
                  label="University Name"
                  required
                  error={!!errors.universityName}
                  helperText={errors.universityName || 'Select your university'}
                />
              )}
            />
          </Grid>
          <Grid item xs={12}>
            <FormTextField
              label="University ID"
              name="universityId"
              value={formData.universityId}
              onChange={handleChange}
              required
              error={errors.universityId}
              helperText={errors.universityId}
            />
          </Grid>
          <Grid item xs={12}>
            <FormControl fullWidth error={!!errors.courseName}>
              <InputLabel id="course-name-label">Course Name</InputLabel>
              <Select
                labelId="course-name-label"
                name="courseName"
                value={formData.courseName}
                onChange={handleChange}
                required
                variant="outlined"
                label="Course Name"
              >
                {availableCourses.map((course) => (
                  <MenuItem key={course} value={course}>{course}</MenuItem>
                ))}
              </Select>
              {errors.courseName && <Typography color="error">{errors.courseName}</Typography>}
            </FormControl>
          </Grid>
          <Grid item xs={12}>
            <FormControl fullWidth error={!!errors.graduationYear}>
              <InputLabel id="graduation-year-label">Graduation Year</InputLabel>
              <Select
                labelId="graduation-year-label"
                name="graduationYear"
                value={formData.graduationYear}
                onChange={handleChange}
                required
                variant="outlined"
                label="Graduation Year"
              >
                {graduationYears.map((year) => (
                  <MenuItem key={year} value={year}>{year}</MenuItem>
                ))}
              </Select>
              {errors.graduationYear && <Typography color="error">{errors.graduationYear}</Typography>}
            </FormControl>
          </Grid>
          <Grid item xs={12}>
            <FormTextField
              label="Bio (Optional)"
              name="bio"
              multiline
              rows={3}
              value={formData.bio}
              onChange={handleChange}
              helperText="Tell us about yourself" // Added helper text
            />
          </Grid>
          <Grid item xs={12}>
            <Autocomplete
              multiple
              options={interestOptions}
              value={formData.interests || []}
              onChange={(e, value) => setFormData({ ...formData, interests: value })}
              renderInput={(params) => (
                <TextField {...params} label="Interests (Optional)" helperText="Select your interests" />
              )}
            />
          </Grid>
          <Grid item xs={12}>
            <Autocomplete
              multiple
              options={accommodationOptions}
              value={formData.accommodationPreferences || []}
              onChange={(e, value) => setFormData({ ...formData, accommodationPreferences: value })}
              renderInput={(params) => (
                <TextField
                  {...params}
                  label="Accommodation Preferences (Optional)"
                  helperText="Select your accommodation preferences"
                />
              )}
            />
          </Grid>
          <Grid item xs={12}>
            <FormTextField
              label="Profile Picture URL (Optional)"
              name="profilePictureURL"
              value={formData.profilePictureURL}
              onChange={handleChange}
              error={errors.profilePictureURL}
              helperText={errors.profilePictureURL || 'Example: https://example.com/image.jpg'}
            />
          </Grid>
          <Grid item xs={12}>
            <FormTextField
              label="LinkedIn (Optional)"
              name="socialMediaLinks.linkedin"
              value={formData.socialMediaLinks.linkedin}
              onChange={handleChange}
              error={errors.linkedin}
              helperText={errors.linkedin || 'Example: https://linkedin.com/in/username'}
            />
          </Grid>
          <Grid item xs={12}>
            <FormTextField
              label="Twitter (Optional)"
              name="socialMediaLinks.twitter"
              value={formData.socialMediaLinks.twitter}
              onChange={handleChange}
              error={errors.twitter}
              helperText={errors.twitter || 'Example: https://twitter.com/username'}
            />
          </Grid>
          <Grid item xs={12}>
            <FormControlLabel
              control={<Checkbox name="termsAccepted" checked={formData.termsAccepted} onChange={handleChange} />}
              label="I accept the terms and conditions"
            />
            {errors.termsAccepted && <Typography color="error">{errors.termsAccepted}</Typography>}
          </Grid>
          <Grid item xs={12}>
            <Button type="submit" variant="contained" color="primary" fullWidth sx={{ mt: 2 }}>
              Sign Up
            </Button>
          </Grid>
        </Grid>
      </form>
    </LocalizationProvider>
  );
};

export default StudentForm;
