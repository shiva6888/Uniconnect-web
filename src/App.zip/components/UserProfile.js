import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import '../App.css';

function UserProfile({ registeredUsers, currentUser, setCurrentUser }) {
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [profileImage, setProfileImage] = useState('');
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    if (!currentUser) {
      navigate('/login');
      return;
    }

    // Initialize form with current user data
    setFirstName(currentUser.firstName || '');
    setLastName(currentUser.lastName || '');
    setProfileImage(currentUser.profileImage || '');
  }, [currentUser, navigate]);

  const handleSubmit = (e) => {
    e.preventDefault();

    // In a real app, this would make an API call to update the user's data
    // Since we're using a JSON file, we'll simulate an update
    const updatedUser = {
      ...currentUser,
      firstName,
      lastName,
      profileImage
    };

    // Find the user index in the users array
    const userIndex = registeredUsers.findIndex(user => user.id === currentUser.id);
    
    if (userIndex !== -1) {
      // Update the user in the users array (in a real app, this would update a database)
      registeredUsers[userIndex] = updatedUser;
      
      // Update the currentUser state and localStorage
      localStorage.setItem('currentUser', JSON.stringify(updatedUser));
      setCurrentUser(updatedUser);
      
      setMessage('Profile updated successfully!');
    }
  };

  return (
    <div className="profile-container">
      <h2>User Profile</h2>
      
      {message && <div className="success-message">{message}</div>}
      
      <form onSubmit={handleSubmit} className="profile-form">
        <div className="form-group">
          <label htmlFor="email">Email (cannot be changed)</label>
          <input
            type="email"
            id="email"
            value={currentUser?.email || ''}
            disabled
          />
        </div>
        
        <div className="form-group">
          <label htmlFor="firstName">First Name</label>
          <input
            type="text"
            id="firstName"
            value={firstName}
            onChange={(e) => setFirstName(e.target.value)}
            required
          />
        </div>
        
        <div className="form-group">
          <label htmlFor="lastName">Last Name</label>
          <input
            type="text"
            id="lastName"
            value={lastName}
            onChange={(e) => setLastName(e.target.value)}
            required
          />
        </div>
        
        <div className="form-group">
          <label htmlFor="profileImage">Profile Image URL</label>
          <input
            type="text"
            id="profileImage"
            value={profileImage}
            onChange={(e) => setProfileImage(e.target.value)}
            placeholder="https://example.com/image.jpg"
          />
        </div>
        
        <button type="submit" className="update-button">Update Profile</button>
      </form>
    </div>
  );
}

export default UserProfile;