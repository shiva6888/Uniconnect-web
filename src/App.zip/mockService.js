// src/mockService.js
export const mockUsers = [
    {
        id: 1,
        email: "test@example.com",
        password: "test123",
        firstName: "Test",
        lastName: "User",
        profile: "student",
        verified: true
    }
];

export const mockService = {
    registerUser: (userSignupPayload) => {
        return new Promise((resolve) => {
            setTimeout(() => {
                // Generate a random OTP
                //validate the user
                //check for uniqueness
                //validate existing student, if a student
                console.log("userSignupPayload", userSignupPayload);
                const otp = Math.floor(1000 + Math.random() * 9000);
                console.log("Generated OTP:", otp);
                resolve({ success: true, otp });
            }, 1000);
        });
    },

    verifyOtp: (userSignupPayload, otp, userOtp) => {
        return new Promise((resolve) => {
            setTimeout(() => {
                // In a real app, you would verify against a stored OTP
                // For mock, we'll just check if the OTP matches
                if (userOtp === otp.toString()) {
                    // Add the user to our mock database
                    const newUser = {
                        id: mockUsers.length + 1,
                        ...userSignupPayload,
                        verified: true
                    };
                    mockUsers.push(newUser);
                    resolve({ success: true, user: mockUsers });
                } else {
                    resolve({ success: false, message: "Invalid OTP" });
                }
            }, 1000);
        });
    },

    loginUser: (email, password) => {
        return new Promise((resolve) => {
            setTimeout(() => {
                const user = mockUsers.find(u =>
                    u.email === email && u.password === password && u.verified
                );

                if (user) {
                    resolve({ success: true, user });
                } else {
                    resolve({
                        success: false,
                        message: "Invalid credentials or account not verified"
                    });
                }
            }, 1000);
        });
    }
};
